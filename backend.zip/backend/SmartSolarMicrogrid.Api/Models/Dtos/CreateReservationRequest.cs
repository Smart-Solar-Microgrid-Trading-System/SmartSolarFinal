/*
 * Project: Smart Solar Microgrid Trading System
 * Component: Energy Reservation Management
 * File: CreateReservationRequest.cs
 * Purpose: Defines validated staff input for creating a reservation for an active Prosumer.
 * Contributor: Rathnayake R.M.S.B
 */
using System.ComponentModel.DataAnnotations;

namespace SmartSolarMicrogrid.Api.Models.Dtos;

public sealed class CreateReservationRequest
{
    public string? ProsumerNic { get; set; }

    [Required]
    public string NodeId { get; set; } = null!;

    [Required]
    public string SlotId { get; set; } = null!;

    [Range(typeof(decimal), "0.01", "79228162514264337593543950335")]
    public decimal EnergyAmountKw { get; set; }
}
